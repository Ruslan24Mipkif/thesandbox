<?php
/**
 * Plugin Name: Услуги Мастера - Авторизация и Элементы
 * Description: Плагин для регистрации, входа, виджетов и шорткодов для сайта "Услуги Мастера".
 * Version: 1.3
 * Author: AI Assistant
 */

// Запрещаем прямой доступ к файлу
if (!defined('WPINC')) {
    die;
}

/**
 * 1. Функция активации плагина: создает таблицы и роли.
 */
register_activation_hook(__FILE__, 'msa_activate_plugin');

function msa_activate_plugin() {
    // Добавляем новую роль "Клиент"
    add_role('client', 'Клиент', ['read' => true]);

    // Создаем таблицу SERVICES для услуг
    global $wpdb;
    $table_name = $wpdb->prefix . 'services';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        service_id mediumint(9) NOT NULL AUTO_INCREMENT,
        service_name tinytext NOT NULL,
        image varchar(255) DEFAULT '' NOT NULL,
        description text NOT NULL,
        `change` text NOT NULL,
        category varchar(100) NOT NULL,
        PRIMARY KEY  (service_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * 2. Подключение CSS-стилей для элементов плагина.
 */
add_action('wp_enqueue_scripts', 'msa_enqueue_styles');

function msa_enqueue_styles() {
    global $post;
    // Подключаем CSS, если на странице есть один из наших шорткодов или активен виджет
    if ( is_a($post, 'WP_Post') && (
            has_shortcode($post->post_content, 'master_registration_form') || 
            has_shortcode($post->post_content, 'master_login_form') ||
            has_shortcode($post->post_content, 'master_sidebar_block')
         ) || is_active_widget(false, false, 'msa_sidebar_widget', true) ) 
    {
        wp_enqueue_style('msa-styles', plugin_dir_url(__FILE__) . 'style.css');
    }
}

/**
 * 3. Шорткод для формы регистрации: [master_registration_form]
 */
add_shortcode('master_registration_form', 'msa_render_registration_form');

function msa_render_registration_form() {
    $errors = [];
    if (isset($_POST['msa_register_nonce']) && wp_verify_nonce($_POST['msa_register_nonce'], 'msa_register_action')) {
        // ... (логика обработки формы остается без изменений) ...
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $address = sanitize_text_field($_POST['address']);
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];

        if (empty($first_name) || empty($email) || empty($password)) $errors[] = 'Пожалуйста, заполните все обязательные поля.';
        if ($password !== $password_confirm) $errors[] = 'Пароли не совпадают.';
        if (email_exists($email)) $errors[] = 'Пользователь с таким email уже существует.';
        
        if (count($errors) === 0) {
            $user_id = wp_create_user($email, $password, $email);
            if (!is_wp_error($user_id)) {
                wp_update_user(['ID' => $user_id, 'first_name' => $first_name, 'last_name' => $last_name, 'role' => 'client']);
                add_user_meta($user_id, 'phone', $phone);
                add_user_meta($user_id, 'address', $address);
                wp_redirect(home_url('/login')); // <-- ИЗМЕНИТЕ '/login' НА ВАШ URL
                exit;
            } else {
                $errors[] = $user_id->get_error_message();
            }
        }
    }

    ob_start();
    ?>
    <div class="msa-form-container">
        <h2>Регистрация</h2>

        <?php if (count($errors) > 0) : ?>
            <div class="msa-errors">
                <?php foreach ($errors as $error) echo '<p>' . esc_html($error) . '</p>'; ?>
            </div>
        <?php endif; ?>

        <form id="msa-registration-form" action="" method="post">
            <div class="form-row">
                <div class="form-field">
                    <!-- Добавлен класс и атрибут для подсказки -->
                    <label for="first_name" class="has-tooltip" data-tooltip="Введите ваше полное имя">Имя</label>
                    <input type="text" name="first_name" id="first_name" required>
                </div>
                <div class="form-field">
                    <label for="last_name">Фамилия</label>
                    <input type="text" name="last_name" id="last_name">
                </div>
            </div>
            <div class="form-row">
                <div class="form-field">
                     <!-- Добавлен класс и атрибут для подсказки -->
                    <label for="email" class="has-tooltip" data-tooltip="Этот email будет использоваться для входа в ваш аккаунт">Электронная почта</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="form-field">
                    <label for="phone">Номер телефона</label>
                    <input type="tel" name="phone" id="phone">
                </div>
            </div>
             <div class="form-row">
                <div class="form-field">
                     <!-- Добавлен класс и атрибут для подсказки -->
                    <label for="password" class="has-tooltip" data-tooltip="Минимум 6 символов. Используйте буквы, цифры и символы.">Пароль</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <div class="form-field">
                    <label for="password_confirm">Подтверждение пароля</label>
                    <input type="password" name="password_confirm" id="password_confirm" required>
                </div>
            </div>
            <div class="form-row">
                 <div class="form-field">
                    <label for="address">Адрес</label>
                    <input type="text" name="address" id="address">
                </div>
                <div class="form-field">
                    <label for="avatar">Аватар</label>
                    <input type="file" name="avatar" id="avatar">
                </div>
            </div>
            <?php wp_nonce_field('msa_register_action', 'msa_register_nonce'); ?>
            <input type="submit" value="Зарегистрироваться">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 4. Шорткод для формы входа: [master_login_form]
 */
add_shortcode('master_login_form', 'msa_render_login_form');

function msa_render_login_form() {
    $login_error = '';
    if (isset($_POST['msa_login_nonce']) && wp_verify_nonce($_POST['msa_login_nonce'], 'msa_login_action')) {
        $creds = ['user_login' => sanitize_email($_POST['email']), 'user_password' => $_POST['password'], 'remember' => true];
        $user = wp_signon($creds, false);

        if (is_wp_error($user)) {
            $login_error = 'Неверный email или пароль.';
        } else {
            wp_redirect(home_url('/account')); // <-- ИЗМЕНИТЕ '/account' НА ВАШ URL
            exit;
        }
    }

    ob_start();
    ?>
    <div class="msa-form-container" style="max-width: 450px;">
        <?php if (!empty($login_error)) : ?>
            <div class="msa-errors"><p><?php echo esc_html($login_error); ?></p></div>
        <?php endif; ?>

        <form id="msa-login-form" action="" method="post">
            <div class="form-field" style="margin-bottom: 15px;"><label for="email">Электронная почта</label><input type="email" name="email" id="email" required></div>
            <div class="form-field"><label for="password">Пароль</label><input type="password" name="password" id="password" required></div>
            <?php wp_nonce_field('msa_login_action', 'msa_login_nonce'); ?>
            <input type="submit" value="Войти">
        </form>
        <p class="msa-register-prompt">У вас нет аккаунта? <a href="/register/">Зарегистрироваться здесь</a></p> <!-- <-- ИЗМЕНИТЕ '/register/' НА ВАШ URL -->
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 5. Шорткод для компактного блока в сайдбаре: [master_sidebar_block]
 */
add_shortcode('master_sidebar_block', 'msa_render_sidebar_shortcode');

function msa_render_sidebar_shortcode() {
    ob_start(); 
    ?>
    <div class="msa-sidebar-block-container">
        <div class="msa-sidebar-item">
            <select name="category-filter">
                <option value="">категории услуг</option>
                <option value="graver">Услуги гравера</option>
                <option value="photographer">Услуги фотографа</option>
                <option value="another">Другая категория</option>
            </select>
        </div>
        <div class="msa-sidebar-item"><a href="#" class="msa-sidebar-button">Новые объявления</a></div>
        <div class="msa-sidebar-item msa-new-listings">
            <div class="msa-listing-item"><div class="placeholder"></div><a href="#">Подробнее</a></div>
            <div class="msa-listing-item"><div class="placeholder"></div><a href="#">Подробнее</a></div>
        </div>
        <div class="msa-sidebar-item msa-map"><img src="<?php echo plugin_dir_url(__FILE__) . 'map-placeholder.png'; ?>" alt="Карта"></div>
        <div class="msa-sidebar-item"><a href="#" class="msa-sidebar-button">Место оказания услуги</a></div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 6. Класс и регистрация виджета для сайдбара.
 */
class MSA_Sidebar_Widget extends WP_Widget {
    function __construct() {
        parent::__construct(
            'msa_sidebar_widget',
            esc_html__('Фильтр Услуг (Услуги Мастера)', 'text_domain'),
            array('description' => esc_html__('Компактная форма для сайдбара с фильтром и объявлениями.', 'text_domain'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        // Для виджета мы просто вызываем функцию шорткода, чтобы не дублировать HTML
        echo do_shortcode('[master_sidebar_block]');
        echo $args['after_widget'];
    }

    public function form($instance) { /* Форма в админке не нужна */ }
    public function update($new_instance, $old_instance) { return $new_instance; }
}

function register_msa_sidebar_widget() {
    register_widget('MSA_Sidebar_Widget');
}
add_action('widgets_init', 'register_msa_sidebar_widget');