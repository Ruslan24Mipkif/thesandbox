document.addEventListener('DOMContentLoaded', function() {
    const themeToggleButton = document.getElementById('theme-toggle-btn');
    const body = document.body;

    // Проверяем, какая тема была сохранена при последнем визите
    const currentTheme = localStorage.getItem('theme');
    if (currentTheme === 'dark') {
        body.classList.add('dark-mode');
    }

    // Обработчик клика по кнопке
    themeToggleButton.addEventListener('click', function() {
        body.classList.toggle('dark-mode');

        // Сохраняем выбор темы
        let theme = 'light';
        if (body.classList.contains('dark-mode')) {
            theme = 'dark';
        }
        localStorage.setItem('theme', theme);
    });
});