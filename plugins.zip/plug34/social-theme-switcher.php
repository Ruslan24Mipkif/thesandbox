<?php
/**
 * Plugin Name:       Social Theme Switcher (PNG Icons)
 * Description:       Добавляет кнопки социальных сетей (Rutube, VK, Telegram) и переключатель тем (светлая/темная) с использованием PNG-иконок.
 * Version:           1.1
 * Author:            Your Name
 */

// Запрещаем прямой доступ к файлу
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Подключение скриптов и стилей
 */
function sts_enqueue_assets() {
    // Получаем URL до папки плагина
    $plugin_url = plugin_dir_url( __FILE__ );

    // Подключаем CSS
    wp_enqueue_style( 'sts-styles', $plugin_url . 'css/style.css' );

    // Подключаем JavaScript. true в конце означает, что скрипт будет загружен в футере
    wp_enqueue_script( 'sts-script', $plugin_url . 'js/main.js', array(), '1.1', true );
}
add_action( 'wp_enqueue_scripts', 'sts_enqueue_assets' );


/**
 * Генерация HTML-кода кнопок с использованием PNG
 */
function sts_display_buttons_html() {
    $plugin_url = plugin_dir_url( __FILE__ );
    $icons_url = $plugin_url . 'icons/';

    // ЗАМЕНИТЕ '#' НА ВАШИ РЕАЛЬНЫЕ ССЫЛКИ
    $rutube_url = '#';
    $telegram_url = '#';
    $vk_url = '#';

    // Формирование тегов <img>
    $rutube_img = '<img src="' . esc_url($icons_url . 'rutube.png') . '" alt="Rutube">';
    $telegram_img = '<img src="' . esc_url($icons_url . 'telegram.png') . '" alt="Telegram">';
    $vk_img = '<img src="' . esc_url($icons_url . 'vk.png') . '" alt="VK">';
    
    $sun_img = '<img class="sts-icon-sun" src="' . esc_url($icons_url . 'sun.png') . '" alt="Светлая тема">';
    $moon_img = '<img class="sts-icon-moon" src="' . esc_url($icons_url . 'moon.png') . '" alt="Темная тема">';

    // Формируем HTML
    $html = '<div class="sts-container">';
    
    // Социальные кнопки
    $html .= '<a href="' . esc_url($rutube_url) . '" target="_blank" rel="noopener noreferrer" title="Rutube">' . $rutube_img . '</a>';
    $html .= '<a href="' . esc_url($telegram_url) . '" target="_blank" rel="noopener noreferrer" title="Telegram">' . $telegram_img . '</a>';
    $html .= '<a href="' . esc_url($vk_url) . '" target="_blank" rel="noopener noreferrer" title="VK">' . $vk_img . '</a>';
    
    // Переключатель темы (используем два разных PNG)
    $html .= '<button id="theme-toggle-btn" title="Переключить тему">';
    $html .= $sun_img;
    $html .= $moon_img;
    $html .= '</button>';
    $html .= '</div>';

    return $html;
}

/**
 * Добавляем шорткод [social_theme_switcher]
 */
add_shortcode( 'social_theme_switcher', 'sts_display_buttons_html' );

/**
 * Автоматически добавляем кнопки в футер сайта
 */
function sts_add_buttons_to_footer() {
    echo do_shortcode('[social_theme_switcher]');
}
add_action( 'wp_footer', 'sts_add_buttons_to_footer' );