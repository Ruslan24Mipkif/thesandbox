<?php
/**
 * Plugin Name: Simple Service Panel
 * Description: Добавляет панель услуг с картой через шорткод [service_panel].
 * Version: 1.0
 * Author: AI Assistant
 * License: GPL2
 */

// Запрещаем прямой доступ к файлу
if (!defined('ABSPATH')) {
    exit;
}

// Функция для подключения стилей плагина
function ssp_enqueue_styles() {
    // Регистрируем и подключаем CSS файл
    wp_enqueue_style(
        'ssp-styles', // Уникальный идентификатор стиля
        plugins_url('css/style.css', __FILE__), // Путь к файлу стилей
        [], // Зависимости (нет)
        '1.0' // Версия файла
    );
}
// Подключаем функцию к хуку WordPress
add_action('wp_enqueue_scripts', 'ssp_enqueue_styles');

// Функция, которая генерирует HTML-код для шорткода
function ssp_generate_panel_html() {
    // Получаем URL изображения карты
    $map_image_url = plugins_url('images/map.png', __FILE__);

    // Начинаем буферизацию вывода, чтобы вернуть HTML как строку
    ob_start();
    ?>
    <div class="ssp-container">
        
        <!-- Выпадающий список категорий -->
        <div class="ssp-form-group">
            <select class="ssp-select">
                <option selected disabled>категории услуг</option>
                <option value="1">Услуга 1</option>
                <option value="2">Услуга 2</option>
                <option value="3">Услуга 3</option>
            </select>
        </div>

        <!-- Кнопка "Новые объявления" -->
        <div class="ssp-form-group">
            <button class="ssp-button">Новые объявления</button>
        </div>

        <!-- Контейнер для объявлений -->
        <div class="ssp-listings">
            <div class="ssp-listing-item">
                <div class="ssp-listing-icon"></div>
                <button class="ssp-button ssp-details-button">Подробнее</button>
            </div>
            <div class="ssp-listing-item">
                <div class="ssp-listing-icon"></div>
                <button class="ssp-button ssp-details-button">Подробнее</button>
            </div>
        </div>

        <!-- Карта -->
        <div class="ssp-map-container">
            <img src="<?php echo esc_url($map_image_url); ?>" alt="Карта" class="ssp-map">
        </div>
        
        <!-- Кнопка "Место оказания услуги" -->
        <div class="ssp-form-group">
            <button class="ssp-button">Место оказания услуги</button>
        </div>

    </div>
    <?php
    // Возвращаем HTML из буфера
    return ob_get_clean();
}
// Регистрируем шорткод [service_panel]
add_shortcode('service_panel', 'ssp_generate_panel_html');